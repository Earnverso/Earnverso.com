export default function Home() {
  return (
    <div style={{ padding: "2rem", fontFamily: "Arial" }}>
      <h1>Welcome to Earnverso.com 🚀</h1>
      <p>This site is deployed with Vercel using a simple Next.js setup.</p>
    </div>
  );
}